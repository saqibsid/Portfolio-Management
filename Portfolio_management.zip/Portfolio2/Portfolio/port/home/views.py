from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import SpecialSkills,Project
from .forms import ProjectForms
from django.contrib import messages
from django.contrib.auth import login, logout,authenticate
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required, permission_required

# Create your views here.
def home(request):
    try:           #if this fails then the except block code will be executed
        data = SpecialSkills.objects.all()    #it will return all the data in it
        # print(data[0])         #as it is stored as a list,we can access it using indexing
        context = {'special':data}
    except Exception as e:
         context = {'special':'Data Not FOund'}
    
    return render(request,'index.html',context)

def project(request):
    try:          
        data = Project.objects.all()    
        context = {'project':data}
    except Exception as e:
         context = {'project':'Data Not FOund'}
    return render(request,'projects.html',context)

@login_required(login_url='loginpage')
@permission_required('home.add_profile',login_url='Home')
def cv(request):
    return render(request,'cv.html')

def projectDetails(request,hm):
    print(hm)
    #fetchData = Project.objects.filter(name=hm)   #will return list of objects
    fetchData = Project.objects.get(name=hm)
    # print(fetchData.query)
    # print(fetchData)
    context = {}
    #context = {'fetchData':fetchData}
    return render(request,'proj_detail.html',context)

def ProjectAdd(request):
    form = ProjectForms
    if request.method =='POST':
        myData = ProjectForms(request.POST)
        if myData.is_valid():
            myData.save()
            messages.success(request,'Project added successfully')
            return redirect('Projects')

    context = {'form':form}
    return render(request,'projAdd.html',context)

def projectdelete(request, id):

    data = Project.objects.get(id=id)

    data.delete()

    return redirect('Projects')



def projectupdate(request, id):

    mydata = Project.objects.get(id=id)

    updateform = ProjectForms(request.POST or None,instance=mydata)

    if updateform.is_valid():

        updateform.save()

        messages.success(request,'Project Updated Successfully')

        return redirect('Projects')

    context = {"form":updateform}

    return render(request,'projectUpdate.html',context)

def hire(request):
    return render(request,'hire-me.html')

def loginpage(request):
    if request.method=='POST':
        username=request.POST['name']
        password=request.POST['password']
        user = authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('Home')
        else:
            print("ERROR 404, Invalid credentials")
            return redirect('Home')    
        # print(email,password)
    return render(request,'login.html')


def logoutpage(request):
    logout(request)
    return redirect('Home')

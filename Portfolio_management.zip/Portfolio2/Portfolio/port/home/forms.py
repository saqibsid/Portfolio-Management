from socket import fromshare
from django import forms
from .models import Project

# class ProjectForms(forms.Form):
#     first_name = forms.CharField(max_length=100)
#     last_name = forms.CharField(max_length=100)
#     roll = forms.CharField(max_length=100)

class ProjectForms(forms.ModelForm):
    class Meta:
        model = Project
        fields = '__all__'
        #fields = ['name','techStack']


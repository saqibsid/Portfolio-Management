
from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.home, name='Home'),
    #project urls
    path('projects/',views.project,name='Projects'),
    path('projDetails/<str:hm>',views.projectDetails,name='details'),  #dynamic url
    path('projAdd/',views.ProjectAdd,name='ProjectAdd'),
    path('projectdelete/<str:id>/',views.projectdelete,name="projectdelete"), # dynamic url
    path('projectupdate/<str:id>/',views.projectupdate,name="projectupdate"), # dynamic url 


    
    
    #cv urls
    path('cvv/',views.cv,name='CV'),
    path('hireMe/',views.hire,name='HireMe'),
    path('loginpage/',views.loginpage,name='loginpage'),
    path('logout/',views.logoutpage,name='logout'),

]
# from django.db.models.signals import post_save, post_delete
# from .models import Project, SpecialSkills
# from django.dispatch import receiver

# @receiver(post_save,sender=Project)
# def autoGenerateSpecialSkills(sender,instance,created,**kwargs):
#     print("signal fired automatically")
#     if created:
#         projectdata = instance
#         # print(projectdata.name)
#         # print(projectdata.techstack)
#         # print(projectdata.description)
#         # print(projectdata.link)
#         SpecialSkills.objects.create(
#             name = projectdata.name,
#             description = projectdata.description,
#         )
#         print("special skills created")

# @receiver(post_delete,sender=Project)     
# def autoSpecialSkillsGone(sender,instance,**kwargs):
#     projectdata = instance
#     # print(projectdata.name)
#     # print(projectdata.techstack)
#     # print(projectdata.description)
#     # print(projectdata.link)
#     fetchdata = SpecialSkills.objects.get(name=projectdata.name)
#     fetchdata.delete()
#     print("Post delete signal called")